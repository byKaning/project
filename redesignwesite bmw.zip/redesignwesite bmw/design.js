const priceSlider = document.getElementById("price-slider");
const priceDisplay = document.getElementById("price-display");

priceSlider.addEventListener("input", updatePrice);

function updatePrice() {
    const selectedPrice = priceSlider.value;
    priceDisplay.textContent = "$" + selectedPrice;
}

// เรียกใช้งานฟังก์ชันเพื่อแสดงราคาเริ่มต้น
updatePrice();
